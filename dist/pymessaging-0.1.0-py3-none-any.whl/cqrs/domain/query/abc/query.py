from abc import ABC


class Query(ABC):
    pass
