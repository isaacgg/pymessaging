from abc import ABC


class Command(ABC):
    pass
